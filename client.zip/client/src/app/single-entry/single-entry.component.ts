import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-single-entry',
  templateUrl: './single-entry.component.html',
  styleUrls: ['./single-entry.component.css']
})
export class SingleEntryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
