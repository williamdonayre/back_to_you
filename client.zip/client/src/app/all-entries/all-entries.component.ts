import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-entries',
  templateUrl: './all-entries.component.html',
  styleUrls: ['./all-entries.component.css']
})
export class AllEntriesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
