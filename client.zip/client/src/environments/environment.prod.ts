export const environment = {
  production: true,
  BASE_URL: 'http://localhost:3000'
};
